<?php
$getroles = array(
    'user',
    'contributor',
    'editor',
    'admin',
    'superadmin',
);
