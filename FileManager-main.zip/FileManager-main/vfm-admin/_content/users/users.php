<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'admin',
    'pass' => '$1$ZaPkqtZs$bn3LCfQSTVOgmYQqsozgV/',
    'role' => 'superadmin',
  ),
);
